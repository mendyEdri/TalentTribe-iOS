//
//  TT_SquareCameraController.h
//  TalentTribe
//
//  Created by Asi Givati on 11/5/15.
//  Copyright © 2015 OnOApps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h>

@class TT_SquareCameraController;
@protocol TT_SquareCameraControllerDelegate <NSObject>

-(void)squareCameraController:(TT_SquareCameraController *)squareCamera didSelecetImage:(UIImage *)image;

@end

@interface TT_SquareCameraController : UIImagePickerController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (weak, nonatomic) id <TT_SquareCameraControllerDelegate>squareCameraDelegate;
@property NSString *cameraMode;

-(TT_SquareCameraController *)initWithCameraMode:(NSString *)cameraMode;

@end
