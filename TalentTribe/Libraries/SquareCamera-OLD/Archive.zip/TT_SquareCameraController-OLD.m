//
//  TT_SquareCameraController.m
//  TalentTribe
//
//  Created by Asi Givati on 11/5/15.
//  Copyright © 2015 OnOApps. All rights reserved.
//

#import "TT_SquareCameraController.h"
#import "GeneralMethods.h"
#define TTSC_BUTTONS_HEIGHT 30

@interface TT_SquareCameraController ()

//@property UIView *bottomBar;
@property UIView *mainOverlayView;
@property UIView *bottomBar;
@property UIImageView *imageArea;
@property UIButton *actionButton;
@property UIButton *cancelButton;
@property UIButton *chooseButton;
@property CGFloat pageBorder;
@property CGFloat cancelButtonYPos;
@property BOOL isVideoMode;
@property BOOL isImageMode;
//@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomBarRightConstraint;
@property BOOL isRecording;
@end

@implementation TT_SquareCameraController


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setGeneralProperties];
    [self setInitialSettings];
    [self setOverlayView];
//    [self setBottomBar];
}

-(void)cropFromUrl:(NSURL *)url
{
    NSURL *videoURL = url;
    NSData *videoData = [NSData dataWithContentsOfURL:videoURL];
    NSString *videoStoragePath;//Set your video storage path to this variable
    [videoData writeToFile:videoStoragePath atomically:YES];
    
    AVAsset *asset = [AVAsset assetWithURL:url];
    
    //create an avassetrack with our asset
    AVAssetTrack *clipVideoTrack = [[asset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    
    //create a video composition and preset some settings
    AVMutableVideoComposition* videoComposition = [AVMutableVideoComposition videoComposition];
    videoComposition.frameDuration = CMTimeMake(1, 30);
    //here we are setting its render size to its height x height (Square)
    
    videoComposition.renderSize = CGSizeMake(clipVideoTrack.naturalSize.height, clipVideoTrack.naturalSize.height);
    
    //create a video instruction
    AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
    instruction.timeRange = CMTimeRangeMake(kCMTimeZero, CMTimeMakeWithSeconds(60, 30));
    
    AVMutableVideoCompositionLayerInstruction* transformer = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:clipVideoTrack];
    
    //Here we shift the viewing square up to the TOP of the video so we only see the top
    CGAffineTransform t1 = CGAffineTransformMakeTranslation(clipVideoTrack.naturalSize.height, -20);
    
    //Use this code if you want the viewing square to be in the middle of the video
    //CGAffineTransform t1 = CGAffineTransformMakeTranslation(clipVideoTrack.naturalSize.height, -(clipVideoTrack.naturalSize.width - clipVideoTrack.naturalSize.height) /2 );
    
    //Make sure the square is portrait
    CGAffineTransform t2 = CGAffineTransformRotate(t1, M_PI_2);
    
    CGAffineTransform finalTransform = t2;
    [transformer setTransform:finalTransform atTime:kCMTimeZero];
    
    //add the transformer layer instructions, then add to video composition
    instruction.layerInstructions = [NSArray arrayWithObject:transformer];
    videoComposition.instructions = [NSArray arrayWithObject: instruction];
    
    //Create an Export Path to store the cropped video
    NSString *outputPath = [NSString stringWithFormat:@"%@%@", NSTemporaryDirectory(), @"video.mp4"];
    NSURL *exportUrl = [NSURL fileURLWithPath:outputPath];
    
    //Remove any prevouis videos at that path
    [[NSFileManager defaultManager]  removeItemAtURL:exportUrl error:nil];
    
    //Export
    AVAssetExportSession *exporter = [[AVAssetExportSession alloc] initWithAsset:asset presetName:AVAssetExportPresetLowQuality] ;
    exporter.videoComposition = videoComposition;
    exporter.outputURL = exportUrl;
    exporter.outputFileType = AVFileTypeMPEG4;
    
    [exporter exportAsynchronouslyWithCompletionHandler:^
     {
         dispatch_async(dispatch_get_main_queue(), ^{
             //Call when finished
//             [self exportDidFinish:exporter];
         });
     }];
}

-(TT_SquareCameraController *)initWithCameraMode:(NSString *)cameraMode
{
    if (self = [super init])
    {
        self.cameraMode = cameraMode;
    }
    return self;
}

-(void)setGeneralProperties
{
    self.pageBorder = [GeneralMethods getCalculateSizeWithScreenSize:screenHeight AndElementSize:20];
    self.isVideoMode = UTTypeConformsTo((__bridge CFStringRef)self.cameraMode, kUTTypeMovie) != 0;
    self.isImageMode = UTTypeConformsTo((__bridge CFStringRef)self.cameraMode, kUTTypeImage) != 0;
}

-(void)setInitialSettings
{
    self.sourceType = UIImagePickerControllerSourceTypeCamera;
    self.delegate = self;
    
    if (self.isImageMode)
    {
        self.extendedLayoutIncludesOpaqueBars = YES;
        self.showsCameraControls = NO;
        self.mediaTypes = [NSArray arrayWithObject:(NSString*)kUTTypeImage];
    }
    else if (self.isVideoMode)
    {
        self.mediaTypes = [NSArray arrayWithObject:(NSString*)kUTTypeMovie];
        self.videoQuality = UIImagePickerControllerQualityTypeHigh;
        self.videoMaximumDuration = 160;
    }
    
//    self.recorder_ = videoRecorder;
//    [videoRecorder release];
//    [self presentModalViewController:self.recorder_ animated:YES];
    
}

-(void)blink
{
    __block UIView *whiteView = [UIView new];
    [whiteView setBackgroundColor:[UIColor whiteColor]];
    [whiteView setAlpha:0.6];
    [whiteView setFrame:self.imageArea.frame];
    [self.imageArea addSubview:whiteView];
    
    [UIView animateWithDuration:0.7 animations:^
    {
        [whiteView setAlpha:0];
    }
    completion:^(BOOL finished)
    {
        [whiteView removeFromSuperview];
        whiteView = nil;
    }];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self animateButtons];
}

-(void)showChooseButton:(BOOL)show
{
    int alpha = (show ? 1:0);
    [UIView animateWithDuration:0.3 animations:^
    {
        [self.chooseButton setAlpha:alpha];
    }];
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    if (self.isImageMode)
    {
        UIImage *takenImage = info[UIImagePickerControllerOriginalImage];
        UIImage *result = [self resizeImage:takenImage withDimension:self.imageArea.frame.size.width];
        [self.imageArea setImage:result];
    }
    else if(self.isVideoMode)
    {
        NSURL *videoURL = [info objectForKey:UIImagePickerControllerMediaURL];
        [self cropFromUrl:videoURL];
    }
}

-(void)setOverlayView
{
//    NSArray *nibArray = [[NSBundle mainBundle] loadNibNamed:@"TT_SquareCameraController" owner:self options:nil];
//    self.mainOverlayView = [nibArray objectAtIndex:0];
    
    self.mainOverlayView = [UIView new];
    self.cameraOverlayView = self.mainOverlayView;
    CGFloat xPos = 0;
    CGFloat yPos = 0;
    CGFloat width = CGRectGetWidth(self.view.frame);
    CGFloat height = CGRectGetHeight(self.view.frame);
    [self.mainOverlayView setFrame:CGRectMake(xPos, yPos, width, height)];
    [self setAreaImageView];
    [self setBottomBar];
}

-(void)setAreaImageView
{
    self.imageArea = [UIImageView new];
    CGFloat imageAreaSize = CGRectGetWidth(self.view.frame);
    [self.imageArea setFrame:CGRectMake(0, 0, imageAreaSize, imageAreaSize)];
    [self.mainOverlayView addSubview:self.imageArea];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (self.isVideoMode)
    {
//        [self.bottomBar removeFromSuperview];
//        [self.actionButton removeFromSuperview];
//        [self.cancelButton removeFromSuperview];
//        [self.chooseButton removeFromSuperview];
//        self.bottomBarRightConstraint.constant = 100;
//        [self.view layoutIfNeeded];
    }
    else
    {
        
    }
}

-(void)setBottomBar
{
    self.bottomBar = [UIView new];
//    [self.bottomBar setAlpha:0.4];
    CGFloat xPos = 0;
    CGFloat yPos = CGRectGetMaxY(self.imageArea.frame);
    CGFloat width = CGRectGetWidth(self.imageArea.frame);
    CGFloat height = CGRectGetHeight(self.view.frame) - CGRectGetHeight(self.imageArea.frame);
    [self.bottomBar setFrame:CGRectMake(xPos, yPos, width, height)];
    
    [self.bottomBar setBackgroundColor:[UIColor blackColor]];
    [self.mainOverlayView addSubview:self.bottomBar];
    
    [self setActionButton];
    [self setCancelButton];
    [self setChooseButton];
}

-(void)setChooseButton
{
    self.chooseButton = [UIButton new];
   
    CGFloat height = [GeneralMethods getCalculateSizeWithScreenSize:screenHeight AndElementSize:TTSC_BUTTONS_HEIGHT];
    CGFloat yPos = self.cancelButtonYPos;
    CGFloat width = CGRectGetWidth(self.view.frame) - CGRectGetMaxX(self.actionButton.frame) - self.pageBorder;
    CGFloat xPos = CGRectGetWidth(self.view.frame) - width - self.pageBorder;
    
    [self.chooseButton setFrame:CGRectMake(xPos, yPos, width, height)];
    self.chooseButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [self.chooseButton setTitle:@"Choose" forState:UIControlStateNormal];
    [self.chooseButton setAlpha:0];
    [self.chooseButton addTarget:self action:@selector(chooseButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.bottomBar addSubview:self.chooseButton];
}

-(void)chooseButtonClicked:(id)sender
{
    if ([self.squareCameraDelegate respondsToSelector:@selector(squareCameraController:didSelecetImage:)])
    {
        [self.squareCameraDelegate squareCameraController:self didSelecetImage:self.imageArea.image];
    }
    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)setCancelButton
{
    self.cancelButton = [UIButton new];
    
    CGFloat xPos = self.pageBorder;
    CGFloat height = [GeneralMethods getCalculateSizeWithScreenSize:screenHeight AndElementSize:TTSC_BUTTONS_HEIGHT];
    CGFloat yPos = CGRectGetHeight(self.bottomBar.frame) + height;
    
    // cancelButtonYPos - after animation
    self.cancelButtonYPos = CGRectGetHeight(self.bottomBar.frame) - height - self.pageBorder;
    
    CGFloat width = self.actionButton.frame.origin.x - self.pageBorder;
    
    [self.cancelButton setFrame:CGRectMake(xPos, yPos, width, height)];
    [self.cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
    self.cancelButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.cancelButton addTarget:self action:@selector(cancelClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.bottomBar addSubview:self.cancelButton];
}

-(void)setActionButton
{
    self.actionButton = [UIButton new];

    CGFloat buttonSize = [GeneralMethods getCalculateSizeWithScreenSize:screenHeight AndElementSize:60];
    CGFloat xPos = 0;
    CGFloat yPos = CGRectGetHeight(self.bottomBar.frame) + buttonSize;
    [self.actionButton setFrame:CGRectMake(xPos, yPos, buttonSize, buttonSize)];
    [self.actionButton setBackgroundColor:[UIColor redColor]];
    [self.actionButton addTarget:self action:@selector(actionButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [GeneralMethods createCircleView:self.actionButton];
    [self.actionButton.layer setBorderColor:[UIColor whiteColor].CGColor];
    CGFloat borderWidth = [GeneralMethods getCalculateSizeWithScreenSize:screenHeight AndElementSize:4];
    [self.actionButton.layer setBorderWidth:borderWidth];
    [self.actionButton setBackgroundColor:[UIColor redColor]];
    self.actionButton.center = CGPointMake(CGRectGetWidth(self.view.frame) / 2, self.actionButton.center.y);
    [self.bottomBar addSubview:self.actionButton];
}

-(void)animateButtons
{
    CGFloat takePictureNewYPos = CGRectGetHeight(self.bottomBar.frame) - CGRectGetHeight(self.actionButton.frame) - self.pageBorder;

    [self animateView:@{@"view": self.actionButton, @"yPos": @(takePictureNewYPos)}];
    [self performSelector:@selector(animateView:) withObject:@{@"view": self.cancelButton, @"yPos": @(self.cancelButtonYPos)} afterDelay:0.3];
}

-(void)animateView:(NSDictionary *)dict
{
    UIView *view = [dict objectForKey:@"view"];
    CGFloat yPos = [[dict objectForKey:@"yPos"]floatValue];
    
    CGFloat distance = 7;
    
    [UIView animateWithDuration:0.7 animations:^
     {
         [GeneralMethods setNew_Ypos:yPos - distance ToView:view];
     }
     completion:^(BOOL finished)
     {
         [UIView animateWithDuration:0.3 animations:^
          {
              [GeneralMethods setNew_Ypos:yPos ToView:view];
          }
          completion:nil];
     }];
}

#pragma mark Buttons Action

-(void)actionButtonClicked:(id)sender
{
    if (self.isImageMode)
    {
        [self handleTakePictureAction];
    }
    else if (self.isVideoMode)
    {
        [self handleVideoCaptureAction];
    }
}

-(void)handleTakePictureAction
{
    [self takePicture];
    [self.cancelButton setTitle:@"Retake" forState:UIControlStateNormal];
    [self showChooseButton:YES];
    [self blink];
}

-(void)handleVideoCaptureAction
{
    if (self.isRecording)
    {
        [super stopVideoCapture];
         self.isRecording = NO;
    }
    else
    {
        [self startVideoCapture];
        self.isRecording = YES;
    }
}

-(void)dismissImageAnimation
{
    CGFloat originalyPos = self.imageArea.frame.origin.y;
    
    [UIView animateWithDuration:0.2 animations:^{
       
        CGFloat newYpos = self.imageArea.frame.origin.y - CGRectGetHeight(self.imageArea.frame);
        [GeneralMethods setNew_Ypos:newYpos ToView:self.imageArea];
    }
     completion:^(BOOL finished)
    {
        self.imageArea.image = nil;
        [GeneralMethods setNew_Ypos:originalyPos ToView:self.imageArea];
     }];
}

-(void)cancelClicked:(id)sender
{
    if (self.imageArea.image) // Retake clicked
    {
        [self dismissImageAnimation];
        [self showChooseButton:NO];
        [self.cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
    }
    else
    {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark Image Handling

- (UIImage*)resizeImage:(UIImage*)image withDimension:(CGFloat)dimension topBarHeight:(CGFloat)topBarHeight
{
    if (nil == image) {
        NSLog(@"Nothing to resize");
        return nil;
    }
    
    image = [self scaleAndRotateImage:image];
    
    CGSize size = [image size];
    
    topBarHeight = size.height * topBarHeight / CGRectGetHeight(self.view.frame);
    
    // Only crop if height != width
    UIImage *newImage;
    if (size.height != size.width) {
        // Create rectangle that represents a square-cropped image.
        // This assumes height > width (portrait mode photo)
        CGRect rect = CGRectMake(0, topBarHeight, size.width, size.width);
        
        // Create bitmap image from original image data,
        // using rectangle to specify desired crop area
        CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], rect);
        newImage = [UIImage imageWithCGImage:imageRef];
        CGImageRelease(imageRef);
    }
    
    return newImage;
}

- (UIImage *) scaleAndRotateImage: (UIImage *)image
{
    int kMaxResolution = 4000; // Or whatever
    
    CGImageRef imgRef = image.CGImage;
    
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    if (width > kMaxResolution || height > kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio > 1) {
            bounds.size.width = kMaxResolution;
            bounds.size.height = bounds.size.width / ratio;
        }
        else {
            bounds.size.height = kMaxResolution;
            bounds.size.width = bounds.size.height * ratio;
        }
    }
    
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef),CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = image.imageOrientation;
    switch(orient)
    {
        case UIImageOrientationUp: //EXIF = 1
            transform = CGAffineTransformIdentity;
            break;
            
        case UIImageOrientationUpMirrored: //EXIF = 2
            transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            break;
            
        case UIImageOrientationDown: //EXIF = 3
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationDownMirrored: //EXIF = 4
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            break;
            
        case UIImageOrientationLeftMirrored: //EXIF = 5
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationRightMirrored: //EXIF = 7
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeScale(-1.0, 1.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        case UIImageOrientationRight: //EXIF = 8
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        default:
            [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
    }
    
    UIGraphicsBeginImageContext(bounds.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft)
    {
        CGContextScaleCTM(context, -scaleRatio, scaleRatio);
        CGContextTranslateCTM(context, -height, 0);
    }
    else {
        CGContextScaleCTM(context, scaleRatio, -scaleRatio);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}

@end
